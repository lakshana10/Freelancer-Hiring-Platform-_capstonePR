alert("client-contracts.js is working");

const API_URL = "http://localhost:8080/api/contracts";

const userEmail = localStorage.getItem("userEmail");
const container = document.getElementById("contractsContainer");

async function loadClientContracts() {

    if (!userEmail) {
        container.innerHTML = `
            <div class="no-contracts">
                <div class="empty-icon">🔐</div>
                <h2>Please Login</h2>
                <p>You need to login to view your contracts.</p>
                <a href="login.html" class="jobs-btn">Login</a>
            </div>
        `;
        return;
    }

    try {
        const response = await fetch(
            `${API_URL}/client/${encodeURIComponent(userEmail)}`
        );

        if (!response.ok) {
            throw new Error("Failed to load contracts");
        }

        const contracts = await response.json();

        if (contracts.length === 0) {
            container.innerHTML = `
                <div class="no-contracts">
                    <div class="empty-icon">📄</div>
                    <h2>No Contracts Yet</h2>
                    <p>You don't have any contracts yet.</p>
                    <a href="jobs.html" class="jobs-btn">
                        Find Jobs →
                    </a>
                </div>
            `;
            return;
        }

        container.innerHTML = "";

        contracts.forEach(contract => {

            const card = document.createElement("div");
            card.className = "contract-card";

            const status = contract.status || "ACTIVE";

            card.innerHTML = `
                <div class="contract-top">

                    <div class="contract-title-section">

                        <div class="contract-icon">📄</div>

                        <div>
                            <h3>
                                ${contract.jobTitle || "Untitled Job"}
                            </h3>

                            <div class="contract-number">
                                Contract #${contract.id}
                            </div>
                        </div>

                    </div>

                    <div class="status">
                        <span class="status-dot"></span>
                        ${status}
                    </div>

                </div>

                <div class="contract-details">

                    <div class="detail-box">
                        <span class="detail-label">Job ID</span>
                        <span class="detail-value">
                            #${contract.jobId}
                        </span>
                    </div>

                    <div class="detail-box">
                        <span class="detail-label">Client</span>
                        <span class="detail-value">
                            ${contract.clientEmail}
                        </span>
                    </div>

                    <div class="detail-box">
                        <span class="detail-label">Freelancer</span>
                        <span class="detail-value">
                            ${contract.freelancerEmail}
                        </span>
                    </div>

                    <div class="detail-box">
                        <span class="detail-label">Contract Status</span>
                        <span class="detail-value">
                            ${status}
                        </span>
                    </div>

                </div>

                <div class="contract-footer">

                    <div class="contract-info">
                        Contract ID:
                        <strong>#${contract.id}</strong>
                    </div>

                    <div class="contract-actions">

                        <button
                            class="details-btn"
                            onclick="showContractDetails(${contract.id})">
                            View Details
                        </button>

                        <button
                            class="review-btn"
                            onclick="giveReview(${contract.id})">
                            ⭐ Give Review
                        </button>

                    </div>

                </div>
            `;

            container.appendChild(card);
        });

    } catch (error) {

        console.error(error);

        container.innerHTML = `
            <div class="no-contracts">
                <div class="empty-icon">⚠️</div>
                <h2>Unable to Load Contracts</h2>
                <p>Please make sure the backend is running.</p>

                <button
                    class="jobs-btn"
                    onclick="loadClientContracts()">
                    Try Again
                </button>
            </div>
        `;
    }
}


function showContractDetails(id) {

    alert(
        "Contract #" + id +
        "\n\nDetailed contract view will be added soon."
    );

}


function giveReview(contractId) {

    window.location.href =
        `give-review.html?contractId=${contractId}`;

}


loadClientContracts();